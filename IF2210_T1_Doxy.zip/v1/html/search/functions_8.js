var searchData=
[
  ['increment',['increment',['../class_point.html#ac6a31803b1aa63e55101c3e7ce6c2d4c',1,'Point']]],
  ['isalive',['isAlive',['../class_makhluk.html#a1677bd235210d490951fcd8a5653160d',1,'Makhluk']]],
  ['isallmakhlukdead',['IsAllMakhlukDead',['../class_l_makhluk.html#abba02c384ab3bb78cf9d4296eb4eafee',1,'LMakhluk']]],
  ['isempty',['isEmpty',['../class_l_makhluk.html#a4ce8d0f4664716ac5237c2bd5bf0463e',1,'LMakhluk']]],
  ['isended',['isEnded',['../class_world.html#acd627d79b89688184df6e9601ffe1532',1,'World']]],
  ['ismakhlukinthesamepoint',['isMakhlukInTheSamePoint',['../class_makhluk.html#af7c17f5cb27935732b277a509ae4dc4b',1,'Makhluk']]],
  ['ispaused',['isPaused',['../class_world.html#ad06b05aabbcbe0c93106793bdb5fcc2c',1,'World']]]
];
