var searchData=
[
  ['makhluk',['Makhluk',['../class_makhluk.html',1,'Makhluk'],['../class_makhluk.html#afd36e7fe75e525a38d5cfc8a1e6b48be',1,'Makhluk::Makhluk()']]],
  ['makhlukeat',['MakhlukEat',['../class_makhluk_live.html#a0c6607d6ae8549c191d87756393a6521',1,'MakhlukLive']]],
  ['makhlukinthesamepoint',['MakhlukInTheSamePoint',['../class_makhluk.html#a5224963edbc85e3dae963cdcab309e40',1,'Makhluk']]],
  ['makhluklive',['MakhlukLive',['../class_makhluk_live.html',1,'']]],
  ['makhlukmove',['MakhlukMove',['../class_makhluk_live.html#a77f878d1062023d807b51ab95fb7937e',1,'MakhlukLive']]],
  ['matrix',['Matrix',['../class_matrix.html',1,'Matrix'],['../class_matrix.html#adfbeb67cc3c43d96c53f881d79f919cb',1,'Matrix::Matrix(int, int)'],['../class_matrix.html#a0b9cfa2302a0273afb1b26e501f93abc',1,'Matrix::Matrix(const Matrix &amp;)']]],
  ['maxage',['maxAge',['../class_makhluk.html#a50350ef02b62af484c769b8118f8c4ae',1,'Makhluk']]],
  ['move',['Move',['../class_hewan.html#aea0228b7a5fc5b15691affeff5ae3099',1,'Hewan']]]
];
