var searchData=
[
  ['age',['age',['../class_makhluk.html#aacf25b9c59e644e709b730f5239996f6',1,'Makhluk']]]
];
