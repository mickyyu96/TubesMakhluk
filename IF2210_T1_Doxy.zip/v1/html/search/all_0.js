var searchData=
[
  ['add',['Add',['../class_l_makhluk.html#ab2d61c43b62e8574b36f486c8907b620',1,'LMakhluk']]],
  ['addanobject',['addAnObject',['../class_world_builder.html#aa3de65bfa04c00b884fd290f44c395c8',1,'WorldBuilder']]],
  ['age',['age',['../class_makhluk.html#aacf25b9c59e644e709b730f5239996f6',1,'Makhluk']]],
  ['ageincrement',['AgeIncrement',['../class_makhluk.html#acc91fe44461c88b854187c7d57f7bb21',1,'Makhluk']]]
];
