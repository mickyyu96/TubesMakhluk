var searchData=
[
  ['maxage',['maxAge',['../class_makhluk.html#a50350ef02b62af484c769b8118f8c4ae',1,'Makhluk']]]
];
