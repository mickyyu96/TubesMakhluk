var searchData=
[
  ['capturesnapshot',['captureSnapshot',['../class_snapshot_capturer.html#a17c1677e94e0cb1e5a17febbb146c4bc',1,'SnapshotCapturer']]],
  ['changepausestate',['changePauseState',['../class_world.html#a1df17b17270667dc2ff9ff52f6ade6c0',1,'World']]]
];
