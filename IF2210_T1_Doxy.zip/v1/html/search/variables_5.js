var searchData=
[
  ['status',['status',['../class_makhluk.html#aa3eefed357a56f6b86f0080083d91d31',1,'Makhluk']]]
];
