var searchData=
[
  ['tumbuhan',['Tumbuhan',['../class_tumbuhan.html',1,'Tumbuhan'],['../class_tumbuhan.html#a3095d94b67888eff7573c5e22620e550',1,'Tumbuhan::Tumbuhan()']]],
  ['turtle',['Turtle',['../class_turtle.html',1,'Turtle'],['../class_turtle.html#a1347c5bcaee6ede82a488394cad3cf00',1,'Turtle::Turtle()']]]
];
