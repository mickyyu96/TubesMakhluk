var searchData=
[
  ['wolf',['Wolf',['../class_wolf.html#adb38a4364ecc382ae56e26a2e3f9d7c2',1,'Wolf']]]
];
